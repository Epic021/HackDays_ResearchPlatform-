from dotenv import load_dotenv
from tools import llm, tools 
from typing import Literal , Annotated,TypedDict
from pydantic import BaseModel, Field 
import prompt_library

load_dotenv()


class QueryLevelSchema(BaseModel):
    technique : Literal["Basic","Chain-of-thought"] = Field(description="The agent to trigger based on the user's query.")
    type : Literal["Product_Based","Depth_Research"] = Field(description="The agent to trigger based on the user's query.")

Agent = llm.with_structured_output(QueryLevelSchema)  

def query_level(user_query: str):
    convo_messages = [
        ("system","""
        You are a prompt engineering router agent. Which type of prompting technique is best suited to answer the given user query?
        If the query is unspecific or it requires basic information, respond with 'Basic'.
        If the query requires step-by-step reasoning or complex problem-solving, respond with 'Chain-of-thought'.
        If the query is focused on generating product-based ideas and solutions, respond with 'Product_Based'.
        If the query requires in-depth research and comprehensive information, respond with 'Depth_Research'.
        """),
        ("human", user_query),
    ]
    result = Agent.invoke(convo_messages)
    print(result)
    print(f"Selected technique: {result.technique}")
    print("---------------------------------------------------")
    return result 


ideation_tool = tools[1:3]  # Selecting Wikipedia and Tavily tools for ideation  
ideation_llm = llm.bind_tools(ideation_tool)

user_query = input("Enter your ideation and also include the direction to your project : ")
level = query_level(user_query)

print(level)
def prompt(level): 
    prompts = []
    if level.technique == "Basic":
        prompts.append(prompt_library.basic_prompt)
    elif level.technique == "Chain-of-thought":
        prompts.append(prompt_library.COT_prompt)

    if level.type == "Product_based":
        prompts.append(prompt_library.product_based_prompt)
    elif level.type == "Depth_research":
        prompts.append(prompt_library.depth_research_prompt)
    return prompts

prompts = prompt(level)
print(prompts)
final_prompt = "  ".join(prompts)
print(final_prompt)

messages = [
    ("system",final_prompt),
    ("human", user_query),
]



response = ideation_llm.invoke(messages)
if hasattr(response, "tool_calls") and response.tool_calls:
    for call in response.tool_calls:
        tool_name = call["name"]
        args = call["args"]
        # Find the matching tool function
        tool_fn = next(t for t in ideation_tool if t.name == tool_name)
        tool_result = tool_fn.invoke(args)
        # Feed tool result back to model
        response = ideation_llm.invoke([
            *messages,
            ("tool", f"Tool '{tool_name}' output: {tool_result}")
        ])

final_ans = response
print(final_ans.content if hasattr(final_ans, "content") else final_ans)

