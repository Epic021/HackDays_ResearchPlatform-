from dotenv import load_dotenv
from tools import llm, tools 
from typing import Literal , Annotated,TypedDict
from pydantic import BaseModel, Field 
import os 

from langchain_tavily import TavilySearch

load_dotenv()
os.environ["GOOGLE_API_KEY"] = os.getenv("GEMINI_API_KEY")
os.environ["TAVILY_API_KEY"] = os.getenv("TAVILY_API_KEY")

tavily_2 = TavilySearch(max_results=10, search_depth="advanced", include_domains=["arxiv.org", "http://www.wikicfp.com/cfp/"])
conference_tool = [tools[0], tavily_2]  # Updating tools to include Arxiv and Tavily for conference

llm_with_conference_tools = llm.bind_tools(conference_tool)
class ConferenceSchema(BaseModel):
    conference_name : str = Field(description="Name of the conference.")
    location : str = Field(description="Location where the conference is being held.")
    date : str = Field(description="Date of the conference.")
    topics_covered : str = Field(description="Topics that will be covered in the conference.")
    submission_deadline : str = Field(description="Submission deadline for papers or abstracts.")
    website : str = Field(description="Official website of the conference.")

conference_llm = llm_with_conference_tools.with_structured_output(ConferenceSchema)
def get_conference_info(query: str):
    response = conference_llm.invoke(query)
    return response


# include_domains (optional, List[str]): List of domains to specifically include. Default is None.